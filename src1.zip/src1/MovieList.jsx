const MovieList = ({ movies, onSelect }) => {
  if (!movies.length) return <p>No movies found</p>

  return (
    <ul>
      {movies.map(movie => (
        <li
          key={movie.imdbID}
          style={{ cursor: "pointer", margin: "8px 0" }}
          onClick={() => onSelect(movie)}
        >
          {movie.Title} ({movie.Year})
        </li>
      ))}
    </ul>
  )
}

export default MovieList
