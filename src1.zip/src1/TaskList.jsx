import React, { useState } from "react";

const TaskList = () => {
  const [tasks, setTasks] = useState([
    { name: "Task 1", status: "done" },
    { name: "Task 2", status: "not done" },
    { name: "Task 3", status: "done" }
  ]);

  const toggleStatus = index => {
    setTasks(prev =>
      prev.map((task, i) =>
        i === index
          ? { ...task, status: task.status === "done" ? "not done" : "done" }
          : task
      )
    );
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Employee Task Management</h2>

      {tasks.map((task, index) => (
        <div
          key={index}
          style={{
            border: "1px solid #ccc",
            padding: 10,
            marginBottom: 10,
            borderRadius: 4
          }}
        >
          <p><strong>{task.name}</strong></p>
          <p>Status: {task.status}</p>

          <button onClick={() => toggleStatus(index)}>
            Toggle Status
          </button>
        </div>
      ))}
    </div>
  );
};

export default TaskList;
