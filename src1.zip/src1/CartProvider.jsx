import { useReducer } from "react"
import { CartContext } from "./CartContext"

// 1. Define action types
const ADD_ITEM = "ADD_ITEM"
const REMOVE_ITEM = "REMOVE_ITEM"
const UPDATE_QUANTITY = "UPDATE_QUANTITY"

// 2. Reducer
function cartReducer(state, action) {
  switch (action.type) {
    case ADD_ITEM: {
      const item = action.payload
      // If item already exists, increase quantity
      const existing = state.find(i => i.id === item.id)
      if (existing) {
        return state.map(i =>
          i.id === item.id ? { ...i, quantity: i.quantity + item.quantity } : i
        )
      }
      // else add new item
      return [...state, { ...item }]
    }

    case REMOVE_ITEM: {
      const { id } = action.payload
      return state.filter(i => i.id !== id)
    }

    case UPDATE_QUANTITY: {
      const { id, quantity } = action.payload
      if (quantity <= 0) {
        // remove if zero or negative
        return state.filter(i => i.id !== id)
      }
      return state.map(i =>
        i.id === id ? { ...i, quantity } : i
      )
    }

    default:
      throw new Error(`Unknown action type: ${action.type}`)
  }
}

// 3. Provider component
export const CartProvider = ({ children }) => {
  const [cart, dispatch] = useReducer(cartReducer, [])

  // Optional helper functions to dispatch actions
  const addItem = item =>
    dispatch({ type: ADD_ITEM, payload: item })

  const removeItem = id =>
    dispatch({ type: REMOVE_ITEM, payload: { id } })

  const updateQuantity = (id, quantity) =>
    dispatch({ type: UPDATE_QUANTITY, payload: { id, quantity } })

  return (
    <CartContext.Provider
      value={{ cart, addItem, removeItem, updateQuantity }}
    >
      {children}
    </CartContext.Provider>
  )
}
