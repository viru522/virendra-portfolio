import React from "react"

const Greeting = () => {
  const hour = new Date().getHours()

  let greeting

  if (hour < 12) {
    greeting = "Good Morning"
  } else if (hour < 18) {
    greeting = "Good Afternoon"
  } else {
    greeting = "Good Evening"
  }

  return <h2>{greeting}</h2>
}

export default Greeting
