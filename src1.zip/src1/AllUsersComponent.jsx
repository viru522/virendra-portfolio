import React, { useState } from "react";
import { users as initialUsers } from "./users";
import SingleUserComponent from "./SingleUserComponent";

function AllUsersComponent() {
  const [userList, setUserList] = useState([]);

  function addAllUsers() {
    setUserList(initialUsers);
  }

  function deleteAllUsers() {
    setUserList([]);
  }

  function deleteSingleUser(id) {
    const updated = userList.filter(user => user.id !== id);
    setUserList(updated);
  }

  const showAddButton = userList.length === 0;

  return (
    <div style={{ padding: "20px" }}>
      <h2>User Management</h2>

      {showAddButton ? (
        <button
          onClick={addAllUsers}
          style={{ padding: "10px 15px", marginBottom: "20px", cursor: "pointer" }}
        >
          Add All Users
        </button>
      ) : (
        <button
          onClick={deleteAllUsers}
          style={{ padding: "10px 15px", marginBottom: "20px", cursor: "pointer" }}
        >
          Delete All Users
        </button>
      )}

      {userList.length > 0 && (
        <table
          border="1"
          cellPadding="10"
          style={{ width: "100%", borderCollapse: "collapse" }}
        >
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Address</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {userList.map(user => (
              <SingleUserComponent
                key={user.id}
                user={user}
                deleteUser={deleteSingleUser}
              />
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default AllUsersComponent;
