import React, { useState, useEffect } from "react";

const Weather = () => {
  const [cityInput, setCityInput] = useState("Amarnath");
  const [city, setCity] = useState("Amarnath");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!city) return;

    const controller = new AbortController();
    const signal = controller.signal;

    const fetchWeather = async () => {
      setLoading(true);
      setError(null);
      setData(null);

      try {
        const res = await fetch(
          `https://api.weatherbit.io/v2.0/current?city=${city}&key=f35038dff73b4557aabf88150ffc02c4`,
          { signal }
        );

        if (!res.ok) throw new Error("Failed to fetch");

        const json = await res.json();

        if (!json.data || json.data.length === 0) {
          throw new Error("No weather data found");
        }

        setData(json.data[0]);
      } catch (err) {
        if (err.name === "AbortError") return;
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchWeather();

    return () => controller.abort();
  }, [city]);

  const handleFetch = () => {
    if (cityInput.trim().length === 0) return;
    setCity(cityInput.trim());
  };

  return (
    <div style={{ padding: 20, maxWidth: 400 }}>
      <h2>Weather Dashboard</h2>

      <div style={{ display: "flex", gap: 8 }}>
        <input
          value={cityInput}
          onChange={e => setCityInput(e.target.value)}
          placeholder="Enter city"
          style={{ flex: 1, padding: 8 }}
        />
        <button onClick={handleFetch} style={{ padding: "8px 12px" }}>
          Get
        </button>
      </div>

      {loading && <p>Loading...</p>}
      {error && <p style={{ color: "red" }}>Error: {error}</p>}

      {data && (
        <div style={{ marginTop: 20, padding: 12, border: "1px solid #ccc" }}>
          <h3>
            {data.city_name}, {data.country_code}
          </h3>
          <p>Temperature: {data.temp} C</p>
          <p>Feels Like: {data.app_temp} C</p>
          <p>Weather: {data.weather.description}</p>
          <p>Wind: {data.wind_spd} m/s</p>
        </div>
      )}
    </div>
  );
};

export default Weather;
