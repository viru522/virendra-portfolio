// import { useContext } from "react"
// import { ThemeContext } from "./ThemeContext"

// const App = () => {
//   const { theme, toggleTheme } = useContext(ThemeContext)

//   const styles = {
//     backgroundColor: theme === "light" ? "#ffffff" : "#1e1e1e",
//     color: theme === "light" ? "#000000" : "#ffffff",
//     minHeight: "100vh",
//     padding: "20px"
//   }

//   return (
//     <div style={styles}>
//       <h1>{theme.toUpperCase()} MODE</h1>
//       <button onClick={toggleTheme}>
//         Toggle Theme
//       </button>

//       <p>This application theme changes using Context API.</p>
//     </div>
//   )
// }

// export default App
import MovieSearch from "./MovieSearch" 
 
const App = () => {   return ( 
    <div style={{ padding: "20px" }}> 
      <h1>Movie Search App</h1> 
      <MovieSearch /> 
    </div> 
  ) 
}  
export default App 
