import React, { useState } from "react";

function LoginStatus() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <div style={{ padding: "20px" }}>
      <h2>Login Status</h2>

      {/* Short circuiting */}
      {isLoggedIn && <p>You are logged in</p>}

      <button
        onClick={() => setIsLoggedIn(!isLoggedIn)}
        style={{
          padding: "8px 14px",
          marginTop: "10px",
          borderRadius: "5px",
          cursor: "pointer"
        }}
      >
        Login
      </button>
    </div>
  );
}

export default LoginStatus;
