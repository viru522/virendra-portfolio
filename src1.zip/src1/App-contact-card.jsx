import React from "react"
import ContactCard from "./ContactCard"

const contacts = [
  {
    name: "Alice Johnson",
    email: "alice.johnson@example.com",
    phone: "555-1234",
    address: "123 Maple Street, Springfield"
  },
  {
    name: "Bob Smith",
    email: "bob.smith@example.com",
    phone: "555-5678",
    address: "456 Oak Avenue, Metropolis"
  },
  {
    name: "Charlie Brown",
    email: "charlie.brown@example.com",
    phone: "555-8765",
    address: "789 Pine Road, Gotham"
  }
]

const App = () => {
  return (
    <div>
      <h1>Contact List</h1>

      {contacts.map((c, index) => (
        <ContactCard 
          key={index}
          name={c.name}
          email={c.email}
          phone={c.phone}
          address={c.address}
        />
      ))}
    </div>
  )
}

export default App

