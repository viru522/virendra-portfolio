import { useContext } from "react"
import { CartContext } from "./CartContext"

const CartView = () => {
  const { cart, removeItem, updateQuantity } = useContext(CartContext)

  if (cart.length === 0) {
    return <p>Your cart is empty.</p>
  }

  return (
    <div>
      <h2>Your Cart</h2>

      {cart.map(item => (
        <div key={item.id} className="cart-item">
          <p>
            {item.name} — ₹{item.price} × {item.quantity}
          </p>
          <div className="cart-actions">
            <button onClick={() => updateQuantity(item.id, item.quantity - 1)}>
              -
            </button>
            <button onClick={() => updateQuantity(item.id, item.quantity + 1)}>
              +
            </button>
            <button onClick={() => removeItem(item.id)}>
              Remove
            </button>
          </div>
        </div>
      ))}

      <div className="total">
        Total: ₹
        {cart.reduce((sum, i) => sum + i.price * i.quantity, 0)}
      </div>
    </div>
  )
}

export default CartView
