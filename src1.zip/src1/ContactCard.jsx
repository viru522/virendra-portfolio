import React from "react"

const ContactCard = props => {
  const { name, email, phone, address } = props

  return (
    <div style={{ 
      border: "1px solid #ccc",
      padding: "12px",
      margin: "10px",
      width: "280px",
      borderRadius: "6px"
    }}>
      <h3>{name}</h3>
      <p>Email: {email}</p>
      <p>Phone: {phone}</p>
      <p>Address: {address}</p>
    </div>
  )
}

export default ContactCard
