import React from 'react'

export const HelloWorld = () => {
  return (
    <div>Hello World!</div>
  )
}
