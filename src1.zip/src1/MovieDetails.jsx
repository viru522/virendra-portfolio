const MovieDetails = ({ movie, onBack }) => {
  if (!movie) return null

  return (
    <div style={{ padding: "20px" }}>
      <button onClick={onBack}>← Back</button>

      <h2>{movie.Title}</h2>
      <p><b>Year:</b> {movie.Year}</p>
      <p><b>Runtime:</b> {movie.Runtime}</p>

      {movie.Poster && (
        <img src={movie.Poster} alt={movie.Title} width="200" />
      )}
    </div>
  )
}

export default MovieDetails
