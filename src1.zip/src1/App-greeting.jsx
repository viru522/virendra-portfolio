import React from "react"
import Greeting from "./Greeting"

const App = () => {
  return (
    <div>
      <Greeting />
    </div>
  )
}

export default App
