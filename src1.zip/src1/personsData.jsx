export const personsData = [
  { name: "John Doe", dateOfBirth: "1990-01-15" },
  { name: "Jane Smith", dateOfBirth: "1985-05-20" },
  { name: "Alice Johnson", dateOfBirth: "1995-09-10" }
];
