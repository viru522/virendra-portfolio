import { useEffect, useState } from "react"
import axios from "axios"
import MovieList from "./MovieList"
import MovieDetails from "./MovieDetails"

const BASE_URL = "https://jsonfakery.com/movies/paginated"

const MovieSearch = () => {
  const [movies, setMovies] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedMovie, setSelectedMovie] = useState(null)
  const [loading, setLoading] = useState(false)

const fetchMovies = async () => {
  setLoading(true)
  try {
    const res = await axios.get(BASE_URL)
    console.log("API RESPONSE:", res.data)
    setMovies(res.data?.data ?? [])
  } catch (err) {
    console.error("API ERROR:", err)
    setMovies([])
  } finally {
    setLoading(false)
  }
}



  useEffect(() => {
    fetchMovies()
  }, [])

  const filteredMovies = movies.filter(movie =>
  movie.title &&
  movie.title.toLowerCase().includes(searchTerm.toLowerCase())
)

  if (selectedMovie) {
    return (
      <MovieDetails
        movie={selectedMovie}
        onBack={() => setSelectedMovie(null)}
      />
    )
  }

  return (
    <>
      <input
        placeholder="Search movies..."
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)}
      />
      <button onClick={fetchMovies}>Search</button>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <MovieList movies={filteredMovies} onSelect={setSelectedMovie} />
      )}
    </>
  )
}

export default MovieSearch
