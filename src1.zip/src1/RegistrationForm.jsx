import { useState } from "react"

const RegistrationForm = () => {
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: ""
  })

  const [errors, setErrors] = useState({})
  const [success, setSuccess] = useState(false)

  const validate = () => {
    const newErrors = {}

    if (!form.firstName) newErrors.firstName = "First name is required"
    if (!form.lastName) newErrors.lastName = "Last name is required"

    if (!form.email) {
      newErrors.email = "Email is required"
    } else if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      newErrors.email = "Invalid email format"
    }

    if (!form.password) newErrors.password = "Password is required"
    if (form.password !== form.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = e => {
    e.preventDefault()
    if (!validate()) return

    setSuccess(true)
    setForm({
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      confirmPassword: ""
    })
  }

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="First Name"
        value={form.firstName}
        onChange={e => setForm({ ...form, firstName: e.target.value })}
      />
      {errors.firstName && <p>{errors.firstName}</p>}

      <input
        placeholder="Last Name"
        value={form.lastName}
        onChange={e => setForm({ ...form, lastName: e.target.value })}
      />
      {errors.lastName && <p>{errors.lastName}</p>}

      <input
        placeholder="Email"
        value={form.email}
        onChange={e => setForm({ ...form, email: e.target.value })}
      />
      {errors.email && <p>{errors.email}</p>}

      <input
        type="password"
        placeholder="Password"
        value={form.password}
        onChange={e => setForm({ ...form, password: e.target.value })}
      />
      {errors.password && <p>{errors.password}</p>}

      <input
        type="password"
        placeholder="Confirm Password"
        value={form.confirmPassword}
        onChange={e =>
          setForm({ ...form, confirmPassword: e.target.value })
        }
      />
      {errors.confirmPassword && <p>{errors.confirmPassword}</p>}

      <button type="submit">Register</button>

      {success && <p style={{ color: "green" }}>Registration successful</p>}
    </form>
  )
}

export default RegistrationForm
