import { useState } from "react"

const BookingForm = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    date: "",
    time: ""
  })

  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)

  const handleSubmit = e => {
    e.preventDefault()

    if (!form.name || !form.email || !form.phone || !form.date || !form.time) {
      setError("All fields are required")
      return
    }

    if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      setError("Invalid email format")
      return
    }

    setError("")
    setSuccess(true)

    setForm({
      name: "",
      email: "",
      phone: "",
      date: "",
      time: ""
    })
  }

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="Full Name"
        value={form.name}
        onChange={e => setForm({ ...form, name: e.target.value })}
      />

      <input
        placeholder="Email"
        value={form.email}
        onChange={e => setForm({ ...form, email: e.target.value })}
      />

      <input
        placeholder="Phone Number"
        value={form.phone}
        onChange={e => setForm({ ...form, phone: e.target.value })}
      />

      <input
        type="date"
        value={form.date}
        onChange={e => setForm({ ...form, date: e.target.value })}
      />

      <input
        type="time"
        value={form.time}
        onChange={e => setForm({ ...form, time: e.target.value })}
      />

      <button type="submit">Book Appointment</button>

      {error && <p style={{ color: "red" }}>{error}</p>}
      {success && (
        <p style={{ color: "green" }}>
          Appointment booked successfully
        </p>
      )}
    </form>
  )
}

export default BookingForm
