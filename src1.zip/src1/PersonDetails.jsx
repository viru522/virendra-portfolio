import React from "react";
import { personsData } from "./personsData";

function PersonDetails() {
  function calculateAge(dob) {
    const birthDate = new Date(dob);
    const today = new Date();

    let age = today.getFullYear() - birthDate.getFullYear();

    const hasNotHadBirthdayThisYear =
      today.getMonth() < birthDate.getMonth() ||
      (today.getMonth() === birthDate.getMonth() &&
        today.getDate() < birthDate.getDate());

    if (hasNotHadBirthdayThisYear) {
      age--;
    }

    return age;
  }

  return (
    <div style={{ padding: "20px" }}>
      <h2>Person Details</h2>

      {personsData.map((person, index) => (
        <div
          key={index}
          style={{
            border: "1px solid #ccc",
            padding: "10px",
            borderRadius: "6px",
            marginBottom: "10px",
            width: "350px"
          }}
        >
          <p><strong>Name:</strong> {person.name}</p>
          <p><strong>Date of Birth:</strong> {person.dateOfBirth}</p>
          <p><strong>Age:</strong> {calculateAge(person.dateOfBirth)}</p>
        </div>
      ))}
    </div>
  );
}

export default PersonDetails;
