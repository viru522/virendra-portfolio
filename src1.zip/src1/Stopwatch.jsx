import React, { useState, useEffect, useRef } from "react";

const formatTime = (secs) => {
  const s = secs % 60;
  const m = Math.floor(secs / 60) % 60;
  const h = Math.floor(secs / 3600);
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s
    .toString()
    .padStart(2, "0")}`;
};

const Stopwatch = () => {
  const [elapsed, setElapsed] = useState(0); // seconds
  const [status, setStatus] = useState("stopped"); // 'stopped' | 'running' | 'paused'
  const intervalRef = useRef(null);

  // Start / resume interval when status === 'running'
  useEffect(() => {
    if (status === "running") {
      // guard: avoid double interval
      if (intervalRef.current) return;

      intervalRef.current = setInterval(() => {
        setElapsed((prev) => prev + 1);
      }, 1000);
    }

    // cleanup: clear interval when status changes away from running or on unmount
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [status]);

  // Handlers
  const handleStart = () => {
    setElapsed(0);
    setStatus("running");
  };

  const handlePause = () => {
    if (status !== "running") return;
    setStatus("paused");
    // interval cleared by useEffect cleanup
  };

  const handleResume = () => {
    if (status !== "paused") return;
    setStatus("running");
  };

  const handleStop = () => {
    setStatus("stopped");
    setElapsed(0);
    // interval cleared by useEffect cleanup
  };

  return (
    <div style={{
      border: "1px solid #ddd",
      padding: "16px",
      borderRadius: 8,
      width: 300,
      textAlign: "center",
      fontFamily: "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif"
    }}>
      <h3 style={{ margin: "0 0 8px 0" }}>Stopwatch</h3>

      <div style={{
        fontSize: 28,
        fontWeight: 600,
        marginBottom: 12,
        letterSpacing: 1
      }}>
        {formatTime(elapsed)}
      </div>

      <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap" }}>
        <button onClick={handleStart} disabled={status === "running"} style={{ padding: "8px 12px" }}>
          Start
        </button>

        <button onClick={handlePause} disabled={status !== "running"} style={{ padding: "8px 12px" }}>
          Pause
        </button>

        <button onClick={handleResume} disabled={status !== "paused"} style={{ padding: "8px 12px" }}>
          Resume
        </button>

        <button onClick={handleStop} disabled={status === "stopped"} style={{ padding: "8px 12px" }}>
          Stop
        </button>
      </div>

      <div style={{ marginTop: 10, fontSize: 12, color: "#666" }}>
        Status: <strong>{status}</strong>
      </div>
    </div>
  );
};

export default Stopwatch;
