import { createContext } from "react"

export const CartContext = createContext(null)  // default value (unused once provided)
